package com.roos.adoptioncenter.adoptionpaper_service.ExceptionsHandling;

public class InvalidInputException extends RuntimeException {
    public InvalidInputException(String message) {
        super(message);
    }
}
