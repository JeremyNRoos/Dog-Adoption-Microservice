package com.roos.adoptioncenter.adoptionpaper_service.domainclientlayer.dog;

public enum ShelterTypeEnum {
    SHELTER,
    FOSTERHOME,
    MEDICALUNIT
}
