package com.roos.adoptioncenter.adoptionpaper_service.businesslayer;


import com.roos.adoptioncenter.adoptionpaper_service.presentationlayer.AdoptionPaperRequestModel;
import com.roos.adoptioncenter.adoptionpaper_service.presentationlayer.AdoptionPaperResponseModel;

import java.util.List;

public interface AdoptionPaperService {
    List<AdoptionPaperResponseModel> getAdoptionPapers();
    AdoptionPaperResponseModel getAdoptionPaperById(String adoptionPaperId);
    AdoptionPaperResponseModel addAdoptionPaper(AdoptionPaperRequestModel adoptionPaperRequestModel);
    AdoptionPaperResponseModel updateAdoptionPaper(AdoptionPaperRequestModel adoptionPaperRequestModel, String adoptionPaperId);
    void deleteAdoptionPaper(String adoptionPaperId);
}
