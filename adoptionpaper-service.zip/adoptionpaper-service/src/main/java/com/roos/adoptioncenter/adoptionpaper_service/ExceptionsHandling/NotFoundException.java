package com.roos.adoptioncenter.adoptionpaper_service.ExceptionsHandling;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {
        super(message);
    }
}
