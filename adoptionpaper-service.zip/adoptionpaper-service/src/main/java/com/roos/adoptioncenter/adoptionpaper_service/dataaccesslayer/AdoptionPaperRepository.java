package com.roos.adoptioncenter.adoptionpaper_service.dataaccesslayer;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdoptionPaperRepository extends MongoRepository<AdoptionPaper, String> {
    AdoptionPaper findAdoptionPaperByAdoptionPaperIdentifier_AdoptionPaperId(String id);
}
