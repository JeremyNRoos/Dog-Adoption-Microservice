package com.roos.adoptioncenter.adoptionpaper_service.businesslayer;

import com.roos.adoptioncenter.adoptionpaper_service.ExceptionsHandling.NotFoundException;
import com.roos.adoptioncenter.adoptionpaper_service.dataaccesslayer.AdoptionPaper;
import com.roos.adoptioncenter.adoptionpaper_service.dataaccesslayer.AdoptionPaperIdentifier;
import com.roos.adoptioncenter.adoptionpaper_service.dataaccesslayer.AdoptionPaperRepository;
import com.roos.adoptioncenter.adoptionpaper_service.domainclientlayer.adopter.AdopterModel;
import com.roos.adoptioncenter.adoptionpaper_service.domainclientlayer.adopter.AdopterServiceClient;
import com.roos.adoptioncenter.adoptionpaper_service.domainclientlayer.dog.DogModel;
import com.roos.adoptioncenter.adoptionpaper_service.domainclientlayer.dog.DogServiceClient;
import com.roos.adoptioncenter.adoptionpaper_service.domainclientlayer.dog.LocationModel;
import com.roos.adoptioncenter.adoptionpaper_service.domainclientlayer.dog.LocationServiceClient;
import com.roos.adoptioncenter.adoptionpaper_service.domainclientlayer.volunteer.VolunteerModel;
import com.roos.adoptioncenter.adoptionpaper_service.domainclientlayer.volunteer.VolunteerServiceClient;
import com.roos.adoptioncenter.adoptionpaper_service.mappinglayer.AdoptionPaperRequestMapper;
import com.roos.adoptioncenter.adoptionpaper_service.mappinglayer.AdoptionPaperResponseMapper;
import com.roos.adoptioncenter.adoptionpaper_service.presentationlayer.AdoptionPaperRequestModel;
import com.roos.adoptioncenter.adoptionpaper_service.presentationlayer.AdoptionPaperResponseModel;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdoptionPaperServiceImpl implements AdoptionPaperService{

    private final VolunteerServiceClient volunteerService;
    private final AdopterServiceClient adopterService;
    private final DogServiceClient dogService;
    private final LocationServiceClient locationService;
    private final AdoptionPaperRepository adoptionPaperRepository;
    private final AdoptionPaperResponseMapper adoptionPaperResponseMapper;
    private final AdoptionPaperRequestMapper adoptionPaperRequestMapper;

    public AdoptionPaperServiceImpl(VolunteerServiceClient volunteerService, AdopterServiceClient adopterService, DogServiceClient dogService, LocationServiceClient locationService, AdoptionPaperRepository adoptionPaperRepository, AdoptionPaperResponseMapper adoptionPaperResponseMapper, AdoptionPaperRequestMapper adoptionPaperRequestMapper) {
        this.volunteerService = volunteerService;
        this.adopterService = adopterService;
        this.dogService = dogService;
        this.locationService = locationService;
        this.adoptionPaperRepository = adoptionPaperRepository;
        this.adoptionPaperResponseMapper = adoptionPaperResponseMapper;
        this.adoptionPaperRequestMapper = adoptionPaperRequestMapper;
    }


    @Override
    public List<AdoptionPaperResponseModel> getAdoptionPapers() {
        List<AdoptionPaper> adoptionPaper = adoptionPaperRepository.findAll();
        List<AdoptionPaperResponseModel> responseModels = new ArrayList<>();

        for (AdoptionPaper adoptionPaper1 : adoptionPaper) {
//            VolunteerModel volunteerResponseModel = volunteerService.getVolunteerById(adoptionPaper1.getVolunteerModel().getId());
//            DogModel dogResponseModel = dogService.getDogById(adoptionPaper1.getLocationModel().getId(), adoptionPaper1.getDogModel().getId());
//            LocationModel locationResponseModel = locationService.getLocationById(adoptionPaper1.getLocationModel().getId());
//            AdopterModel adopterResponseModel = adopterService.getAdopterById(adoptionPaper1.getAdopterModel().getId());

            AdoptionPaperResponseModel responseModel = adoptionPaperResponseMapper.toResponseModel(adoptionPaper1);
//            responseModel.setAdopterFName(adopterResponseModel.getFName());
//            responseModel.setAdopterLName(adopterResponseModel.getLName());
//
//            responseModel.setDogName(dogResponseModel.getName());
//            responseModel.setDogAge(dogResponseModel.getAge());
//
//            responseModel.setLocationName(locationResponseModel.getName());
//
//            responseModel.setVolunteerFName(volunteerResponseModel.getFName());
//            responseModel.setVolunteerLName(volunteerResponseModel.getLName());
//
////            responseModel.setDog(dogResponseModel);
//            responseModel.setLocation(locationResponseModel);
//            responseModel.setAdopter(adopterResponseModel);

            responseModels.add(responseModel);
        }





        return responseModels;
    }

    @Override
    public AdoptionPaperResponseModel getAdoptionPaperById(String adoptionPaperId) {
        AdoptionPaper adoptionPaper = adoptionPaperRepository.findAdoptionPaperByAdoptionPaperIdentifier_AdoptionPaperId(adoptionPaperId);
        if(adoptionPaper == null){
            throw new NotFoundException("No adoption paper with ID: " + adoptionPaperId);
        }
//        VolunteerModel volunteerResponseModel = volunteerService.getVolunteerById(adoptionPaper.getVolunteerModel().getId());
//        DogModel dogResponseModel = dogService.getDogById(adoptionPaper.getLocationModel().getId(), adoptionPaper.getDogModel().getId());
//        LocationModel locationResponseModel = locationService.getLocationById(adoptionPaper.getLocationModel().getId());
//        AdopterModel adopterResponseModel = adopterService.getAdopterById(adoptionPaper.getAdopterModel().getId());

        return adoptionPaperResponseMapper.toResponseModel(adoptionPaper);

//        responseModel.setAdopterFName(adopterResponseModel.getFName());
//        responseModel.setAdopterLName(adopterResponseModel.getLName());
//
//        responseModel.setDogName(dogResponseModel.getName());
//        responseModel.setDogAge(dogResponseModel.getAge());
//
//        responseModel.setLocationName(locationResponseModel.getName());
//
//        responseModel.setVolunteerFName(volunteerResponseModel.getFName());
//        responseModel.setVolunteerLName(volunteerResponseModel.getLName());

    }

    @Override
    public AdoptionPaperResponseModel addAdoptionPaper(AdoptionPaperRequestModel adoptionPaperRequestModel) {
            if(adoptionPaperRequestModel == null){
            throw new IllegalArgumentException("Invalid identifier provided for volunteer, dog, location, or adopter");
            }

            DogModel dogResponseModel = dogService.getDogById(adoptionPaperRequestModel.getLocationModel().getId(), adoptionPaperRequestModel.getDogModel().getId());
            LocationModel locationResponseModel = locationService.getLocationById(adoptionPaperRequestModel.getLocationModel().getId());
            AdopterModel adopterResponseModel = adopterService.getAdopterById(adoptionPaperRequestModel.getAdopterModel().getId());
            VolunteerModel volunteerResponseModel = volunteerService.getVolunteerById(adoptionPaperRequestModel.getVolunteerModel().getId());

//            dogService.updateDogAvailability(adoptionPaperRequestModel.getDogIdentifier(), false); Invariant

            AdoptionPaperIdentifier adoptionPaperIdentifier = new AdoptionPaperIdentifier();

            AdoptionPaper adoptionPaper = adoptionPaperRequestMapper.requestToEntity(adoptionPaperRequestModel,
                    adoptionPaperIdentifier,
                    volunteerResponseModel,
                    locationResponseModel,
                    dogResponseModel,
                    adopterResponseModel);

            AdoptionPaper adoptionPaperSaved = adoptionPaperRepository.save(adoptionPaper);
            return adoptionPaperResponseMapper.toResponseModel(adoptionPaperSaved);
    }

    @Override
    public AdoptionPaperResponseModel updateAdoptionPaper(AdoptionPaperRequestModel adoptionPaperRequestModel, String adoptionPaperId) {
        AdoptionPaper adoptionPaper = adoptionPaperRepository.findAdoptionPaperByAdoptionPaperIdentifier_AdoptionPaperId(adoptionPaperId);
        if(adoptionPaper == null){
            throw new NotFoundException("No adoption paper with ID: " + adoptionPaperId);
        }

        DogModel dogModel = dogService.getDogById(adoptionPaperRequestModel.getLocationModel().getId(), adoptionPaperRequestModel.getDogModel().getId());
        AdopterModel adopterModel = adopterService.getAdopterById(adoptionPaperRequestModel.getAdopterModel().getId());
        VolunteerModel volunteerModel = volunteerService.getVolunteerById(adoptionPaperRequestModel.getVolunteerModel().getId());
        LocationModel locationModel = locationService.getLocationById(adoptionPaperRequestModel.getLocationModel().getId());

        adoptionPaper.setDogModel(dogModel);
        adoptionPaper.setAdopterModel(adopterModel);
        adoptionPaper.setVolunteerModel(volunteerModel);
        adoptionPaper.setLocationModel(locationModel);

        AdoptionPaper existingPaper = adoptionPaperRepository.save(adoptionPaper);
        return adoptionPaperResponseMapper.toResponseModel(existingPaper);
    }

    @Override
    public void deleteAdoptionPaper(String adoptionPaperId) {
        AdoptionPaper adoptionPaper = adoptionPaperRepository.findAdoptionPaperByAdoptionPaperIdentifier_AdoptionPaperId(adoptionPaperId);
        if(adoptionPaper == null){
            throw new NotFoundException("No adoption paper with ID" + adoptionPaperId);
        }
        adoptionPaperRepository.delete(adoptionPaper);
    }
}
