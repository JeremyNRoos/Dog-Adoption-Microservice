package com.roos.adoptioncenter.adoptionpaper_service.presentationlayer;



import com.roos.adoptioncenter.adoptionpaper_service.businesslayer.AdoptionPaperService;
import com.roos.adoptioncenter.adoptionpaper_service.mappinglayer.AdoptionPaperResponseMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/adoptionPapers")
public class AdoptionPaperController {
    private final AdoptionPaperService adoptionPaperService;

    public AdoptionPaperController(AdoptionPaperService adoptionPaperService) {
        this.adoptionPaperService = adoptionPaperService;
    }


    @GetMapping()
    public ResponseEntity<List<AdoptionPaperResponseModel>> getAdoptionPapers(){
        List<AdoptionPaperResponseModel> adoptionPaperResponseModels = adoptionPaperService.getAdoptionPapers();
        return ResponseEntity.ok().body(adoptionPaperResponseModels);
    }

    @GetMapping("/{adoptionPaperId}")
    public ResponseEntity<AdoptionPaperResponseModel> getAdoptionPaperById(@PathVariable String adoptionPaperId){
        AdoptionPaperResponseModel adoptionPaperResponseModel = adoptionPaperService.getAdoptionPaperById(adoptionPaperId);
        return ResponseEntity.ok().body(adoptionPaperResponseModel);
    }

    @PostMapping()
    public ResponseEntity<AdoptionPaperResponseModel> addAdoptionPaper(@RequestBody AdoptionPaperRequestModel adoptionPaperRequestModel){
        AdoptionPaperResponseModel adoptionPaperResponseModel = adoptionPaperService.addAdoptionPaper(adoptionPaperRequestModel);
        return new ResponseEntity<>(adoptionPaperResponseModel, HttpStatus.CREATED);
    }

    @PutMapping("/{adoptionPaperId}")
    public ResponseEntity<AdoptionPaperResponseModel> UpdateAdoptionPaper(@RequestBody AdoptionPaperRequestModel adoptionPaperRequestModel, @PathVariable String adoptionPaperId){
        AdoptionPaperResponseModel adoptionPaperResponseModel = adoptionPaperService.updateAdoptionPaper(adoptionPaperRequestModel, adoptionPaperId);
        return new ResponseEntity<>(adoptionPaperResponseModel, HttpStatus.OK);
    }

    @DeleteMapping("/{adoptionPaperId}")
    public ResponseEntity<Void> deleteAdoptionPaper(@PathVariable String adoptionPaperId){
        adoptionPaperService.deleteAdoptionPaper(adoptionPaperId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
