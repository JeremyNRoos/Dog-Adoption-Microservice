INSERT INTO adopter (adopter_id, f_name, l_name, address, city, province, country, postal_code, type, phone_number,
                     contact_method_preference)
VALUES ('fcbf86b1-8a76-4d2b-a352-75b10a8fd4a1', 'John', 'Doe', '123 Maple St', 'Toronto', 'Ontario', 'Canada', 'M5A 1A1', 'MOBILE', '416-123-4567','PHONE'),
       ('3ad1cbf0-3fd4-42b7-8a42-e15b3936945d', 'Jane', 'Smith', '456 Oak Ave', 'Vancouver', 'British Columbia', 'Canada', 'V6B 3K3', 'HOME','604-987-6543', 'EMAIL'),
       ('5f81fc19-2f9c-45f5-9f00-c18d7d064bb9', 'Michael', 'Brown', '789 Pine Rd', 'Montreal', 'Quebec', 'Canada', 'H2X 2L2', 'WORK','514-555-7890', 'TEXT'),
       ('2d636d57-e0e6-4d7a-9b8d-f5f8e441d0a7', 'Emily', 'Johnson', '321 Birch Blvd', 'Calgary', 'Alberta', 'Canada', 'T2P 5G8', 'MOBILE','403-222-3333', 'EMAIL'),
       ('68069d51-bc1c-4a41-9ac3-508690a0141c', 'David', 'Williams', '159 Cedar St', 'Halifax', 'Nova Scotia', 'Canada', 'B3J 1W9', 'HOME','902-444-5555', 'PHONE'),
       ('77c90518-0605-4801-b69c-18e1a2d93a4f', 'Sophia', 'Taylor', '753 Spruce Ln', 'Winnipeg', 'Manitoba', 'Canada', 'R3C 4N1', 'WORK','204-666-7777', 'TEXT'),
       ('a82f1f3a-4354-4a1e-8f0a-39b4d3969fc3', 'Daniel', 'Martinez', '951 Aspen Ct', 'Ottawa', 'Ontario', 'Canada', 'K1A 0B1', 'MOBILE','613-777-8888', 'EMAIL'),
       ('7e933f35-2f56-4d7c-a683-bb0aab09905d', 'Olivia', 'Anderson', '357 Redwood Ave', 'Edmonton', 'Alberta', 'Canada', 'T5J 3E5', 'HOME','780-123-4567', 'PHONE'),
       ('c3cb3b2f-1085-4939-8368-19c3ea5b2673', 'Matthew', 'Harris', '258 Elm Dr', 'Regina', 'Saskatchewan', 'Canada', 'S4P 3Y2', 'WORK','306-888-9999', 'TEXT'),
       ('2950d211-f436-4a4e-85e7-93e6f3542999', 'Emma', 'Clark', '684 Fir Way', 'Victoria', 'British Columbia', 'Canada', 'V8W 2E7', 'MOBILE','250-111-2222', 'EMAIL');