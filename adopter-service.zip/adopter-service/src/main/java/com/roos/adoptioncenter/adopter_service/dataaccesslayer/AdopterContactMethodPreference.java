package com.roos.adoptioncenter.adopter_service.dataaccesslayer;

public enum AdopterContactMethodPreference {
    EMAIL,
    PHONE,
    TEXT
}
